/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;
import java.util.*;
import modele.Fonds;
import modele.Instrument;

/**
 *
 * @author charlottedecary
 */
public class Statistiques {
    
    public void afficherInstrum(Instrument i){
        
    }
    public void afficherFonds(Fonds f){
        
    }
    
}
